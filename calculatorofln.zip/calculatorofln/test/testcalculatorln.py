"""unit test cases for ln function"""
import unittest
import test.calculatorln


class TestlnMethod(unittest.TestCase):
    """checks for postive value"""
    def test_ln_postive(self):
        """checks for positive value"""
        result = test.calculatorln.lnfunc(2)
        self.assertEqual(result, 0.6931471805599453)

    def test_ln_negative(self):
        """checks for negative value"""
        result = test.calculatorln.lnfunc(-2)
        self.assertEqual(result, "-NAN-")

    def test_ln_zero(self):
        """checks for zero value"""
        result = test.calculatorln.lnfunc(0)
        self.assertEqual(result, "infinity")


if __name__ == '__main__':
    unittest.main()
