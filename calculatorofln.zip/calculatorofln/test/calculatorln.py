import math
# class calculatorln:
#     def __init__(self,y):
#         self.y=y

def lnfunc(x):
    if x > 0:
        result= math.log(x)
        print(result)
    elif x == 0:
        result="infinity"
        print(result)
    else:
        result="-NAN-"
        print(result)
    return result

# if __name__ == '__main__':
x=int(input("Enter the value"))
lnfunc(x)
# calc=calculatorln(x)


