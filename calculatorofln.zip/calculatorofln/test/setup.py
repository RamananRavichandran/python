from setuptools import setup,find_packages
setup(
   name='ln',
   version='1.0',
   description='ln function of calculator',
   author='Ramanan',
   author_email='gr.ramanan@2010@gmail.com',
   packages=find_packages(exclude=['*tests*']),  #same as name
   #install_requires=['math'], #external packages as dependencies
)