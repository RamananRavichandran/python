from django.apps import AppConfig


class AseRegisterConfig(AppConfig):
    name = 'ase_register'
